Crypto Traders websites gives live chatrooms with hundreds of experts giving realtime analytics and alerts.

Set up:-
 1. Clone the project from gitlab.
 2.Initialize npm to create a package.json file, then install webpack locally.
 3.Installing Bootstrap.
 4.Create a webpack configuration file
 5. Project structure:- 
    assets>images
    sass > app.scss
 6. Importing Bootstrap Sass:-
   scss > app.scss
7. Bundling with Webpack
8. Edit package.json file to add a npm script to run the webpack command.
 